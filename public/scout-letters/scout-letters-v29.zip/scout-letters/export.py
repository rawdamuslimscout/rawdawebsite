"""Generate an editable Arabic letter on a selected scout letterhead."""
import argparse
import io
from copy import deepcopy
import json
import re
import sys
from pathlib import Path
from statistics import median

from docx import Document
from docx.enum.table import WD_TABLE_DIRECTION, WD_TABLE_ALIGNMENT
from docx.text.paragraph import Paragraph
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt
from PIL import Image, ImageChops, ImageOps

ROOT = Path(__file__).resolve().parent
DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789')

def fmt(p, value='', align=WD_ALIGN_PARAGRAPH.RIGHT, bold=False, size_pt=12, space_after=5, line_spacing=1.15):
    p.alignment = align
    if align == WD_ALIGN_PARAGRAPH.RIGHT:
        p._p.get_or_add_pPr().find(qn("w:jc")).set(qn("w:val"), "start")
    elif align == WD_ALIGN_PARAGRAPH.LEFT:
        p._p.get_or_add_pPr().find(qn("w:jc")).set(qn("w:val"), "end")
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = line_spacing
    p._p.get_or_add_pPr().append(OxmlElement('w:bidi'))
    if value:
        add_text(p, value, size_pt, bold)
    return p

def add_text(p, value, size_pt, bold):
    run = p.add_run(value)
    run.font.name = 'Arial'
    run.font.size = Pt(size_pt)
    run.bold = bold
    prop = run._r.get_or_add_rPr()
    prop.rFonts.set(qn('w:cs'), 'Arial')
    size = OxmlElement('w:szCs')
    size.set(qn('w:val'), str(size_pt * 2))
    prop.append(size)
    if bold:
        prop.append(OxmlElement('w:bCs'))
    if re.search(r'[\u0600-\u06ff]', value):
        run.font.rtl = True

def clean_signature(image):
    """Remove a uniform background and crop the transparent padding."""
    alpha = image.getchannel('A')
    if alpha.getextrema() == (255, 255):
        rgb = image.convert('RGB')
        width, height = rgb.size
        pixels = rgb.load()
        border = [pixels[x, y] for x in range(width) for y in (0, height - 1)]
        border += [pixels[x, y] for y in range(height) for x in (0, width - 1)]
        background = tuple(int(median(channel)) for channel in zip(*border))
        difference = ImageChops.difference(rgb, Image.new('RGB', rgb.size, background))
        red, green, blue = difference.split()
        distance = ImageChops.lighter(ImageChops.lighter(red, green), blue)
        matching = sum(max(abs(a-b) for a, b in zip(px, background)) <= 22 for px in border)
        if matching >= .92 * len(border):
            candidate = distance.point([max(0, min(255, (x-18)*255//24)) for x in range(256)])
            removed = candidate.histogram()[0]
            if .15 * width * height <= removed <= .995 * width * height:
                if max(background) < 70:
                    # Neutral white ink from a dark image needs contrast on paper.
                    light_ink = [px for px, opacity in zip(rgb.getdata(), candidate.getdata()) if opacity >= 224]
                    if light_ink and sum(min(px) >= 175 and max(px)-min(px) <= 30 for px in light_ink) >= .97 * len(light_ink):
                        image = Image.new('RGBA', image.size, (28, 28, 28, 255))
                image.putalpha(candidate)
                alpha = candidate
    bounds = alpha.getbbox()
    if bounds is None:
        raise ValueError('الصورة شفافة بالكامل. أرفق صورة يظهر فيها الإمضاء أو الختم.')
    return image.crop(bounds)

def image(p, path, width_mm, height_mm=18):
    if not path:
        p.paragraph_format.line_spacing = Pt(13)
        p.paragraph_format.space_after = Pt(0)
        return
    path = Path(path)
    if path.stat().st_size > 10_000_000:
        raise ValueError('Use a PNG or JPEG under 10 MB')
    with Image.open(path) as src:
        if src.format not in ('PNG','JPEG'):
            raise ValueError('Signature and stamp images must be PNG or JPEG')
        if src.width * src.height > 20_000_000:
            raise ValueError('Images must be under 20 megapixels')
        src = ImageOps.exif_transpose(src).convert('RGBA')
        src.thumbnail((1200, 1200))
        src = clean_signature(src)
        stream = io.BytesIO()
        src.save(stream, format='PNG')
        stream.seek(0)
        scale = min(width_mm / src.width, height_mm / src.height)
        p.add_run().add_picture(stream, width=Mm(src.width * scale))

def signatures(doc, data):
    secretary_default = (
        data.get('document_type') != 'circular'
        or bool((data.get('secretary_name') or '').strip() or data.get('secretary_signature'))
    )
    secretary = data.get('has_secretary', secretary_default)
    if type(secretary) is not bool:
        raise ValueError('has_secretary must be true or false')
    people = []
    if secretary:
        people.append(('أمين السر', data.get('secretary_signature'), data.get('secretary_name','')))
    else:
        people.append(('', None, ''))
    if data.get('stamp'):
        people.append(('', data['stamp'], ''))
    people.append((data['reference'], data.get('sender_signature'), data.get('sender_name','')))
    table = doc.add_table(rows=1, cols=len(people))
    row = table.rows[0]
    if not secretary and data.get('stamp'):
        section = doc.sections[-1]
        available = (section.page_width - section.left_margin - section.right_margin) / Mm(1)
        narrow = min(40, available / 3)
        table.autofit = False
        for col, cell, width in zip(table.columns, row.cells, (available - 2*narrow, narrow, narrow)):
            col.width = cell.width = Mm(width)
    table.table_direction = WD_TABLE_DIRECTION.RTL
    row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
    for cell, (role, photo, name) in zip(row.cells, people):
        center = WD_ALIGN_PARAGRAPH.CENTER
        fmt(cell.paragraphs[0], role, center, bold=True, space_after=1, line_spacing=1.0)
        is_stamp = bool(photo and not role and not name and photo == data.get('stamp'))
        image(fmt(cell.add_paragraph(), align=center, space_after=1, line_spacing=1.0),
              photo, 33, 26 if is_stamp else 18)
        if name:
            fmt(cell.add_paragraph(), name, center, space_after=0, line_spacing=1.0)

def export(data, outdir):
    catalog = json.loads((ROOT/'templates/index.json').read_text(encoding='utf-8'))
    troop = data.get('troop','')
    if troop not in catalog:
        raise ValueError('No approved template for that troop')
    data = dict(data)
    kind = data.get('document_type', 'minutes' if troop == 'minutes' else 'letter')
    labels = {'letter': 'رقم الصادر', 'minutes': 'محضر رقم', 'circular': 'تعميم رقم'}
    if not isinstance(kind, str) or kind not in labels:
        raise ValueError('حدّد نوع المستند: رسالة أو محضر أو تعميم')
    if troop == 'minutes' and kind != 'minutes':
        raise ValueError('قالب محضر الاجتماع مخصّص للمحاضر')
    number_label = labels[kind]
    fields = {
        'date': 'التاريخ الميلادي',
        'hijri_date': 'التاريخ الهجري',
        'number': number_label,
        'reference': 'المرسِل (المرجع)',
        'subject': 'الموضوع',
    }
    if kind != 'minutes':
        fields['recipient'] = 'المرسَل إليه'
    missing = []
    for field, label in fields.items():
        value = data.get(field)
        if not isinstance(value, str) or not value.strip():
            missing.append(label)
        else:
            data[field] = value.strip()
    if missing:
        raise ValueError('أكمل الحقول المطلوبة: ' + '، '.join(missing))
    number = data['number']
    number = number.strip().translate(DIGITS)
    if not re.fullmatch(r'[0-9]{1,12}/[0-9]{4}', number) or int(number.split('/')[0]) < 1 or number.endswith('/0000'):
        raise ValueError(f'أدخل {number_label} بصيغة رقم موجب/سنة من أربع خانات، مثل 12/2026')
    subject = data['subject']
    filename = re.sub(r'[<>:"/\\|?*\x00-\x1f\u202a-\u202e\u2066-\u2069]', ' ', subject)
    filename = ' '.join(filename.split())[:85].strip(' .')
    if not filename:
        raise ValueError('Provide a usable subject')
    blocks = data.get('body')
    if isinstance(blocks, str):
        blocks = [blocks] if blocks.strip() else []
    if blocks is None:
        blocks = []
    if not isinstance(blocks, list):
        raise ValueError('Body must be text or a list of paragraphs, headings, or tables')
    blocks = [block for block in blocks if not isinstance(block, str) or block.strip()]
    for block in blocks:
        if isinstance(block, str):
            continue
        if isinstance(block, dict) and (
            (set(block) == {'heading'} and isinstance(block['heading'], str) and block['heading'].strip())
            or (set(block) == {'runs'} and isinstance(block['runs'], list) and bool(block['runs'])
                and all(isinstance(run, dict) and set(run) <= {'text', 'bold'}
                        and isinstance(run.get('text'), str) and isinstance(run.get('bold', False), bool)
                        for run in block['runs'])
                and any(run['text'].strip() for run in block['runs']))
            or set(block) == {'table'}
        ):
            continue
        raise ValueError('Each body block must be a paragraph, heading, or table')
    if not blocks and not (troop == 'minutes' and data.get('agenda')):
        raise ValueError('Add the letter body')
    number_line = f'{number_label}: \u200e{number}\u200e'
    doc = Document(ROOT/'templates'/f'{troop}.docx')
    if troop == 'minutes':
        minutes(doc, data, number_line, subject, blocks)
    else:
        letter(doc, data, number_line, subject, blocks, troop)
    basmala = OxmlElement('w:p')
    doc._element.body.insert(0, basmala)
    opening = fmt(Paragraph(basmala, doc), 'بسم الله الرحمن الرحيم',
                  WD_ALIGN_PARAGRAPH.CENTER, bold=True, size_pt=14, space_after=10)
    opening.paragraph_format.keep_with_next = True
    if data.get('is_test') is True:
        notice = OxmlElement('w:p')
        basmala.addnext(notice)
        marker = fmt(Paragraph(notice, doc), 'نموذج تجريبي — غير صالح للإرسال',
                     WD_ALIGN_PARAGRAPH.CENTER, bold=True, size_pt=11)
        marker.paragraph_format.keep_with_next = True
    stem = number.replace('/','-') + ' - ' + filename
    buffer = io.BytesIO()
    doc.save(buffer)
    return write_unique(outdir, stem, '.docx', buffer.getbuffer())

def write_unique(outdir, stem, extension, content):
    index = 1
    while True:
        suffix = '' if index == 1 else f' ({index})'
        output = Path(outdir) / f'{stem}{suffix}{extension}'
        try:
            stream = output.open('xb')
        except FileExistsError:
            index += 1
            continue
        with stream:
            stream.write(content)
        return output

def put(cell, value, align=WD_ALIGN_PARAGRAPH.RIGHT, *, space_before=0, **style):
    cell.text = ''
    paragraph = fmt(cell.paragraphs[0], value, align, **style)
    paragraph.paragraph_format.space_before = Pt(space_before)

def fill_header_names(doc, data, *, general=False):
    def field(key):
        value = data.get(key) or ''
        if not isinstance(value, str):
            raise ValueError('أدخل أسماء الجهات كنص')
        return value.strip()

    arabic = [field(key) for key in ('troop_ar', 'unit_ar', 'subunit_ar')]
    english = [field(key) for key in ('troop_en', 'unit_en', 'subunit_en')]
    legation = field('legation_ar')
    if general and not (legation or any(arabic)):
        raise ValueError('أدخل اسم المفوضية أو الفوج أو الوحدة المرسِلة')
    if not general and not (legation and arabic[0]):
        raise ValueError('أدخل اسمَي المفوضية والفوج لقالب المحضر')
    legation_en = field('legation_en')
    if not general:
        arabic, english = arabic[:1], english[:1]
    paired = zip([legation, *arabic], [legation_en, *english])
    missing = [name for name, translated in paired if name and not re.search(r'[A-Za-z]', translated)]
    if missing:
        raise ValueError('أضف الأسماء بالإنكليزية للترويسة: ' + '، '.join(missing))
    english = [translated if name else '' for name, translated in zip(arabic, english)]
    if not legation:
        legation_en = ''
    names = {
        '(إسم المفوضية)': [legation],
        '(Legation name)': [legation_en],
        '(إسم الفوج)': arabic,
        '(Troop name)': english,
    }
    for paragraph in doc.sections[0].header._element.iter(qn('w:p')):
        nodes = [n for run in paragraph.iterchildren(qn('w:r')) for n in run.iterchildren(qn('w:t'))]
        value = ''.join(n.text or '' for n in nodes).strip()
        if value in names:
            lines = [line for line in names[value] if line]
            nodes[0].text = lines[0] if lines else ''
            anchor = nodes[0]
            for line in lines[1:]:
                br = OxmlElement('w:br')
                anchor.addnext(br)
                label = OxmlElement('w:t')
                label.text = line
                br.addnext(label)
                anchor = label
            for node in nodes[1:]:
                node.text = ''

def letter(doc, data, number_line, subject, blocks, troop):
    date = (data.get('date') or '').strip()
    city = (data.get('city') or '').strip()
    hijri = (data.get('hijri_date') or '').strip()
    reference = (data.get('reference') or '').strip()
    metadata = [
        (f'{city} في {date}' if city else f'التاريخ الميلادي: {date}') if date else '',
        f'الموافق له: {hijri}' if hijri else '',
        number_line,
    ]
    if troop in ('general', 'north'):
        if troop == 'general':
            fill_header_names(doc, data, general=True)
        # Remove the blank sample body or regional floating metadata box.
        doc._element.body.clear_content()
        for line in filter(None, metadata):
            fmt(doc.add_paragraph(), line, WD_ALIGN_PARAGRAPH.LEFT)
        for line in [data.get('recipient',''), 'السلام عليكم ورحمة الله وبركاته،', 'تحية كشفية وبعد،']:
            if line:
                paragraph = fmt(doc.add_paragraph(), line)
                if line == data.get('recipient'):
                    paragraph.paragraph_format.space_before = Pt(8)
        topic_line = fmt(doc.add_paragraph(), 'الموضوع: '+subject, bold=True, size_pt=14, space_after=3)
        topic_line.paragraph_format.space_before = Pt(5)
        if reference:
            fmt(doc.add_paragraph(), 'المرجع: '+reference)
        closing = doc.add_paragraph()
    else:
        dates, topic = doc.tables
        dates.alignment = WD_TABLE_ALIGNMENT.LEFT
        dates.autofit = False
        section = doc.sections[-1]
        available = section.page_width - section.left_margin - section.right_margin
        width = int(available * .60)
        preferred = dates._tbl.tblPr.find(qn('w:tblW'))
        preferred.set(qn('w:type'), 'dxa')
        preferred.set(qn('w:w'), str(round(width / 635)))
        for column in dates.columns:
            column.width = width // len(dates.columns)
        for row, line in zip(dates.rows, metadata):
            row.cells[0].width = width
            if line:
                put(row.cells[0],line)
            else:
                dates._tbl.remove(row._tr)
        for line in [data.get('recipient',''), 'السلام عليكم ورحمة الله وبركاته،', 'تحية كشفية وبعد،']:
            if line:
                node = OxmlElement('w:p')
                topic._tbl.addprevious(node)
                paragraph = fmt(Paragraph(node, doc), line)
                if line == data.get('recipient'):
                    paragraph.paragraph_format.space_before = Pt(8)
        put(topic.cell(0,0),'الموضوع: '+subject,bold=True,size_pt=14,space_after=3,space_before=5)
        if reference:
            put(topic.cell(1,0),'المرجع: '+reference)
        else:
            topic._tbl.remove(topic.rows[1]._tr)
        closing = doc.add_paragraph()
    anchor = closing._p
    for index, block in enumerate(blocks):
        added = None
        if isinstance(block, str):
            added = fmt(doc.add_paragraph(), block, size_pt=13, space_after=8, line_spacing=1.25)._p
        elif 'runs' in block:
            paragraph = fmt(doc.add_paragraph(), size_pt=13, space_after=8, line_spacing=1.25)
            for part in block['runs']:
                add_text(paragraph, part['text'], 13, part.get('bold', False))
            added = paragraph._p
        elif 'heading' in block:
            heading = fmt(doc.add_paragraph(), block['heading'], bold=True, size_pt=13, space_after=6)
            heading.paragraph_format.keep_with_next = True
            added = heading._p
        else:
            rows = block['table']
            if (not isinstance(rows, list) or not rows
                    or not all(isinstance(row, list) for row in rows)
                    or not 1 <= len(rows[0]) <= 8 or any(len(r) != len(rows[0]) for r in rows)):
                raise ValueError('Use a rectangular table with 1–8 columns')
            table = doc.add_table(rows=0, cols=len(rows[0]))
            added = table._tbl
            table.style = 'Table Grid'
            table.table_direction = WD_TABLE_DIRECTION.RTL
            key_value = len(rows[0]) == 2 and str(rows[0][0]).strip() in ('البند', 'العنصر')
            if key_value:
                section = doc.sections[-1]
                width = section.page_width - section.left_margin - section.right_margin
                table.autofit = False
                table.columns[0].width = int(width * .28)
                table.columns[1].width = int(width * .72)
            for idx, values in enumerate(rows):
                row = table.add_row()
                row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader' if idx == 0 else 'w:cantSplit'))
                for col, cell, value in zip(table.columns, row.cells, values):
                    if key_value:
                        cell.width = col.width
                    fmt(cell.paragraphs[0], str(value), bold=idx == 0,
                        size_pt=11, space_after=3, line_spacing=1.12)
        if added.tag == qn('w:p'):
            paragraph = Paragraph(added, doc)
            if index == 0 or isinstance(blocks[index - 1], dict) and 'table' in blocks[index - 1]:
                paragraph.paragraph_format.space_before = Pt(7)
            if index == len(blocks) - 1:
                paragraph.paragraph_format.keep_with_next = True
        anchor.addprevious(added)
    fmt(closing, 'دمتم ذخرًا للحركة الكشفية', WD_ALIGN_PARAGRAPH.LEFT, space_after=3)
    closing.paragraph_format.space_before = Pt(4)
    closing.paragraph_format.keep_with_next = True
    signatures(doc, data)

def minutes(doc, data, number_line, subject, blocks):
    fill_header_names(doc, data)
    # This template contains empty spacer paragraphs inherited from the sample.
    # Remove those without touching the table cells or the final section setup.
    for paragraph in doc.paragraphs:
        element = paragraph._p
        if not paragraph.text.strip() and not element.xpath(
            './/w:drawing|.//w:pict|.//w:object|.//w:sectPr|.//w:fldSimple|.//w:instrText'
        ):
            element.getparent().remove(element)
    header, agenda, original_signatures = doc.tables
    for i, j, value in [
        (0,3,subject),(0,4,number_line),(1,4,'الميلادي: '+data['date']+'\nالموافق له: '+data['hijri_date']),
        (2,0,'البدء  '+data['start'] if data.get('start') else ''),(2,2,'الانتهاء  '+data['end'] if data.get('end') else ''),
        (2,3,'المكان  '+data['location'] if data.get('location') else ''),(3,1,data.get('attendance','')),
        (4,1,data.get('absences','')),
    ]:
        put(header.cell(i,j),value)
    reference = (data.get('reference') or '').strip()
    if reference:
        fmt(header.cell(0,3).add_paragraph(), 'المرجع: '+reference, size_pt=11)
    prototype=deepcopy(agenda.rows[1]._tr)
    for row in agenda.rows[1:5]:
        agenda._tbl.remove(row._tr)
    rows = data.get('agenda') or [[subject, '\n'.join(
        x if isinstance(x, str) else ''.join(run['text'] for run in x.get('runs', []))
        for x in blocks if isinstance(x, str) or 'runs' in x
    ), '']]
    if not isinstance(rows, list) or any(
        not isinstance(row, list) or len(row) != 3 or not all(isinstance(value, str) for value in row)
        for row in rows
    ):
        raise ValueError('Each minutes agenda row needs three text values: topic, discussion, and assignment')
    for i,(topic, discussion, assignment) in enumerate(rows,1):
        agenda._tbl.insert(agenda._tbl.index(agenda.rows[-2]._tr),deepcopy(prototype))
        row=agenda.rows[-3]
        for idx,value in [(0,str(i)),(1,topic),(2,discussion),(4,assignment)]:
            put(row.cells[idx],value)
    put(agenda.rows[-2].cells[0],'ملاحظات  '+data.get('notes',''))
    next_date = data.get('next_meeting_date','')
    next_time = data.get('next_meeting_time','')
    if next_date or next_time:
        put(agenda.rows[-1].cells[0], 'الاجتماع القادم  '+next_date if next_date else '')
        put(agenda.rows[-1].cells[-1], 'الساعة  '+next_time if next_time else '')
    else:
        agenda._tbl.remove(agenda.rows[-1]._tr)
    original_signatures._tbl.getparent().remove(original_signatures._tbl)
    closing = fmt(doc.add_paragraph(), 'دمتم ذخرًا للحركة الكشفية', WD_ALIGN_PARAGRAPH.LEFT, space_after=3)
    closing.paragraph_format.space_before = Pt(4)
    closing.paragraph_format.keep_with_next = True
    signatures(doc,data)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('data', help='Letter data JSON')
    parser.add_argument('outdir')
    parser.add_argument('--format', choices=('docx',), default='docx', help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        data = json.loads(Path(args.data).read_text(encoding='utf-8'))
        print(export(data, args.outdir))
    except (ValueError, OSError) as exc:
        sys.exit(str(exc))
