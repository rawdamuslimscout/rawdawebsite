"""Targeted WordprocessingML regressions. Run with python3 -m unittest test_export."""
import json
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from export import export, fmt, ROOT


class ExportTests(unittest.TestCase):
    def test_existing_bidi_is_normalized_without_duplication(self):
        paragraph = Document().add_paragraph()
        paragraph._p.get_or_add_pPr().append(OxmlElement('w:bidi'))
        fmt(paragraph, 'عنوان', bold=True)
        fmt(paragraph)
        paragraph.paragraph_format.keep_with_next = True
        properties = paragraph._p.pPr
        tags = [element.tag for element in properties]
        self.assertEqual(tags.count(qn('w:bidi')), 1)
        self.assertLess(tags.index(qn('w:keepNext')), tags.index(qn('w:bidi')))
        self.assertLess(tags.index(qn('w:bidi')), tags.index(qn('w:spacing')))
        self.assertLess(tags.index(qn('w:bidi')), tags.index(qn('w:jc')))
        tags = [element.tag for element in paragraph.runs[0]._r.rPr]
        self.assertLess(tags.index(qn('w:b')), tags.index(qn('w:bCs')))
        self.assertLess(tags.index(qn('w:bCs')), tags.index(qn('w:sz')))
        self.assertLess(tags.index(qn('w:sz')), tags.index(qn('w:szCs')))
        self.assertLess(tags.index(qn('w:szCs')), tags.index(qn('w:rtl')))

    def test_all_templates_export_with_ordered_generated_properties(self):
        catalog = json.loads((ROOT / 'templates/index.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory() as folder:
            for troop in catalog:
                with self.subTest(troop=troop):
                    path = export({
                        'troop': troop, 'number': '12/2026', 'date': 'تاريخ تجريبي',
                        'hijri_date': 'تاريخ تجريبي', 'subject': 'لقاء تدريبي',
                        'reference': 'قائد التدريب', 'recipient': 'حضرة القائد المحترم،',
                        'body': ['نص تجريبي'], 'legation_ar': 'مفوضية تجريبية',
                        'legation_en': 'Test Legation', 'troop_ar': 'فوج تجريبي',
                        'troop_en': 'Test Troop', 'is_test': True,
                    }, Path(folder))
                    document = Document(path)
                    for ppr in document._element.body.xpath('.//w:pPr[w:bidi and w:jc]'):
                        tags = [element.tag for element in ppr]
                        self.assertEqual(tags.count(qn('w:bidi')), 1)
                        self.assertLess(tags.index(qn('w:bidi')), tags.index(qn('w:jc')))
                    if troop == 'general':
                        with ZipFile(path) as package:
                            for name in package.namelist():
                                if name.startswith('word/header') and name.endswith('.xml'):
                                    self.assertNotIn(b'w:hint="cs"', package.read(name))


if __name__ == '__main__':
    unittest.main()
